/* Copyright (C) 2020 by EL KANTRI Youssef - ENSA of Fez, Morocco */

a couple of functions that can analyze an array of unsigned char data items 
and report analytics on the maximum, minimum, mean, and median of the data 
set and reorder this data set from large to small,
All statistics are rounded down to the nearest integer
show that data to the screen in nicely formatted presentation.
