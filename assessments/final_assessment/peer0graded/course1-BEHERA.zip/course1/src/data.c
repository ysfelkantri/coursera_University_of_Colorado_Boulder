#include "data.h"

//###############################################################################

uint8_t my_itoa(int32_t data, uint8_t * ptr, uint32_t base)
{

int32_t temp=0,str[32]={0};
int i=0, len=0 ;
//char  str[10]={0}; 
// maximum length of 32 bit string is 10 and negative and with nulset

if (data < 0)
{
data= data*-1;
*ptr='-';
ptr++;
len++;
}

str[0]='\0';
i++;
len++;

if(base == 2 || base == 8 || base == 10) // Bin Oct Dec 
{

while(data !=0)
{
 str[i++]=(data%base)+48;
 data=data/base;
 len++;
}

}

else if(base == 16)
{
 while (data != 0)
 {
 temp = data % 16;          
 if (temp < 10)
 str[i++] = 48 + temp;   
 else
 str[i++] = 55 + temp;   
 data = data / 16;            
 len++;
 }

}

for (i ; i >= 0; i--)
{
 *ptr=str[i];
 ptr++;
}

ptr=ptr-len;

return len;
}

//###############################################################################

int32_t my_atoi(uint8_t * ptr, uint8_t digits, uint32_t base)
{
int32_t value=0;
uint8_t flag=0;

if (*ptr == '-')
{
ptr++;
digits--;
flag=1;
}
else
flag =0;


if (base ==2 || base == 8 || base == 10)
{
for(size_t i=1 ; i<digits;i++)
{
value = value + *(ptr+i)-48;
value=value*base;
}  
value = value/base;
}

else if(base ==16)
{
 for(size_t i=1 ; i < digits;i++)
 {
  
  if( *(ptr+i) <= '9')
   value = value + *(ptr+i)-48;
  
  else
   value = value + *(ptr+i)-55;

   value = value*base;
 } 
 value = value/base;
}

if (flag !=0)
value = value*-1;

return value;
}
